==================================
QuantFinance — Documentation
==================================

Bienvenue dans la documentation de `quantfinance`, une bibliothèque Python pour la finance quantitative.

.. toctree::
   :maxdepth: 2
   :caption: Modules:

   portfolio
   pricing
   risk
   utils

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`